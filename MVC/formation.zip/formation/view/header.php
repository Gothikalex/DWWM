<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>titre</title>
</head>
<body>
    <ul>
        <li><a href="http://localhost/DWWM/MVC/formation/student/add">ajouter un student</a></li><br>
        <li><a href="http://localhost/DWWM/MVC/formation/course/add">ajouter un cours</a></li><br>
        <li><a href="http://localhost/DWWM/MVC/formation/student/affiche_student">afficher les students</a></li><br>
        <li><a href="http://localhost/DWWM/MVC/formation/course/affiche_course">afficher les cours</a></li><br>
        <li><a href="http://localhost/DWWM/MVC/formation/inscription/inscription">inscrire un étudiant à des cours</a></li><br>
    </ul>
</body>
</html>